import React, { useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  Activity, AlertTriangle, ArrowLeft, ArrowRight, Bell, CalendarDays,
  Check, ChevronRight, Clock3, FileText, HeartPulse, Home, Lock,
  MessageCircle, Pill, Plus, QrCode, Search, ShieldCheck, Sparkles,
  Stethoscope, UserRound, Users, X
} from "lucide-react";
import "./styles.css";

const initialPatients = [
  {
    id: "CASE-1024",
    name: "Rahul Sharma",
    age: 46,
    sex: "M",
    blood: "B+",
    allergies: ["Penicillin"],
    conditions: ["Type 2 Diabetes", "Hypertension"],
    medications: ["Metformin 500 mg", "Amlodipine 5 mg"],
    visits: 12,
    reports: 17,
    prescriptions: 8,
    events: [
      { year: "2024", type: "Diagnosis", title: "Type 2 Diabetes diagnosed", place: "CityCare Hospital", icon: "heart" },
      { year: "2024", type: "Prescription", title: "Metformin 500 mg started", place: "CityCare Hospital", icon: "pill" },
      { year: "2025", type: "Investigation", title: "HbA1c — 8.6%", place: "Metro Labs", icon: "report" },
      { year: "2025", type: "Consultation", title: "Hypertension follow-up", place: "Government Hospital", icon: "doctor" },
      { year: "2026", type: "Consultation", title: "Current visit — headache", place: "Case360 Clinic", icon: "doctor" }
    ]
  },
  {
    id: "CASE-2048",
    name: "Priya Shah",
    age: 31,
    sex: "F",
    blood: "O+",
    allergies: ["None recorded"],
    conditions: ["Migraine"],
    medications: ["None"],
    visits: 6,
    reports: 9,
    prescriptions: 4,
    events: [
      { year: "2024", type: "Consultation", title: "Migraine episode", place: "CityCare Clinic", icon: "doctor" },
      { year: "2025", type: "Investigation", title: "MRI brain — no acute findings", place: "Metro Diagnostics", icon: "report" },
      { year: "2026", type: "Consultation", title: "Routine follow-up", place: "Case360 Clinic", icon: "doctor" }
    ]
  }
];

const questions = [
  { key: "complaint", bot: "What brings you to the doctor today?", placeholder: "e.g. I've had a headache for five days." },
  { key: "location", bot: "Where do you feel the problem, and what does it feel like?", placeholder: "e.g. Forehead and temples, throbbing." },
  { key: "duration", bot: "When did it start, and how severe is it from 1–10?", placeholder: "e.g. 5 days, around 6/10." },
  { key: "associated", bot: "Any associated symptoms such as fever, vomiting, vision changes, weakness or nausea?", placeholder: "e.g. Mild nausea, no fever or vomiting." },
  { key: "meds", bot: "Have you taken anything for it? Also mention regular medicines.", placeholder: "e.g. Paracetamol twice; metformin regularly." }
];

function App() {
  const [mode, setMode] = useState("patient");
  const [page, setPage] = useState("home");
  const [patients, setPatients] = useState(initialPatients);
  const [selectedId, setSelectedId] = useState(initialPatients[0].id);
  const [toast, setToast] = useState("");
  const [shareOpen, setShareOpen] = useState(false);

  const selected = patients.find(p => p.id === selectedId) || patients[0];

  const notify = (msg) => {
    setToast(msg);
    setTimeout(() => setToast(""), 2800);
  };

  const openPatient = (id) => {
    setSelectedId(id);
    setPage("patient");
  };

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand" onClick={() => setPage("home")}>
          <div className="brandmark"><HeartPulse size={21}/></div>
          <div>
            <strong>Case360</strong>
            <span>Intelligent Patient Case Taking</span>
          </div>
        </div>
        <div className="mode-switch">
          <button className={mode === "patient" ? "active" : ""} onClick={() => {setMode("patient"); setPage("home")}}><UserRound size={16}/> Patient</button>
          <button className={mode === "doctor" ? "active" : ""} onClick={() => {setMode("doctor"); setPage("doctor")}}><Stethoscope size={16}/> Doctor</button>
        </div>
        <div className="top-actions"><Bell size={19}/><div className="avatar">{mode === "doctor" ? "DR" : "RS"}</div></div>
      </header>

      <main className="main">
        {mode === "patient" && page === "home" && (
          <PatientHome patient={selected} onStart={() => setPage("case")} onRecords={() => setPage("patient")} onShare={() => setShareOpen(true)} />
        )}
        {mode === "patient" && page === "patient" && (
          <PatientRecord patient={selected} onBack={() => setPage("home")} onShare={() => setShareOpen(true)} />
        )}
        {mode === "patient" && page === "case" && (
          <CaseTaking patient={selected} onBack={() => setPage("home")} onComplete={(caseData) => {
            setPatients(prev => prev.map(p => p.id === selected.id ? {
              ...p,
              visits: p.visits + 1,
              events: [...p.events, { year: "2026", type: "Consultation", title: `${caseData.complaint || "New consultation"}`, place: "Case360 Clinic", icon: "doctor" }]
            } : p));
            setPage("review");
          }} />
        )}
        {mode === "patient" && page === "review" && (
          <CaseReview patient={selected} onBack={() => setPage("case")} onConfirm={() => {notify("Case verified and added to health timeline."); setPage("patient")}} />
        )}
        {mode === "doctor" && page === "doctor" && (
          <DoctorDashboard patients={patients} onOpen={openPatient} />
        )}
        {mode === "doctor" && page === "doctorPatient" && (
          <DoctorPatient patient={selected} onBack={() => setPage("doctor")} onSave={(rx) => {
            setPatients(prev => prev.map(p => p.id === selected.id ? {
              ...p,
              prescriptions: p.prescriptions + 1,
              events: [...p.events, { year: "2026", type: "Prescription", title: rx, place: "Case360 Clinic", icon: "pill" }]
            } : p));
            notify("Doctor-verified prescription added to patient timeline.");
          }} />
        )}
      </main>

      {toast && <div className="toast"><Check size={17}/>{toast}</div>}
      {shareOpen && <ShareModal onClose={() => setShareOpen(false)} onShare={() => {setShareOpen(false); notify("Temporary access created for 2 hours.")}} />}
    </div>
  );
}

function PageTitle({ eyebrow, title, sub, back, action }) {
  return <div className="page-title">
    <div>
      {back && <button className="back" onClick={back}><ArrowLeft size={16}/> Back</button>}
      <div className="eyebrow">{eyebrow}</div>
      <h1>{title}</h1>
      {sub && <p>{sub}</p>}
    </div>
    {action}
  </div>
}

function PatientHome({patient,onStart,onRecords,onShare}) {
  return <div>
    <div className="hero">
      <div>
        <div className="eyebrow">YOUR HEALTH, IN CONTEXT</div>
        <h1>Welcome back, {patient.name.split(" ")[0]} <span>👋</span></h1>
        <p>Start today's consultation with your previous medical history already in context.</p>
        <button className="primary big" onClick={onStart}><MessageCircle size={19}/> Start new case</button>
      </div>
      <div className="hero-card">
        <div className="mini-label">HEALTH PROFILE</div>
        <div className="profile-row"><div className="big-avatar">{patient.name.split(" ").map(x=>x[0]).join("")}</div><div><strong>{patient.name}</strong><span>{patient.age} years • {patient.sex} • {patient.blood}</span></div></div>
        <div className="profile-id"><span>ABHA-linked demo ID</span><strong>{patient.id}</strong></div>
        <div className="profile-safe"><ShieldCheck size={15}/> Patient-controlled sharing</div>
      </div>
    </div>

    <section className="section">
      <div className="section-head"><div><div className="eyebrow">HEALTH SNAPSHOT</div><h2>Your record at a glance</h2></div><button className="text-btn" onClick={onRecords}>View full history <ArrowRight size={15}/></button></div>
      <div className="stats">
        <Stat icon={<CalendarDays/>} value={patient.visits} label="Consultations"/>
        <Stat icon={<FileText/>} value={patient.reports} label="Reports"/>
        <Stat icon={<Pill/>} value={patient.prescriptions} label="Prescriptions"/>
        <Stat icon={<Activity/>} value={patient.conditions.length} label="Known conditions"/>
      </div>
    </section>

    <section className="grid-2">
      <div className="panel">
        <div className="panel-title"><span><AlertTriangle size={18}/> Important</span></div>
        <div className="alert"><div className="alert-icon">!</div><div><strong>Allergy recorded</strong><p>{patient.allergies.join(", ")}</p></div></div>
        <p className="muted">Always verify allergies with a clinician before treatment.</p>
      </div>
      <div className="panel share-panel">
        <div className="panel-title"><span><Lock size={18}/> Your records, your control</span></div>
        <p>Share only the information a doctor needs, for a limited period.</p>
        <button className="secondary" onClick={onShare}><QrCode size={17}/> Create temporary access</button>
      </div>
    </section>
  </div>
}

function Stat({icon,value,label}) { return <div className="stat"><div className="stat-icon">{icon}</div><strong>{value}</strong><span>{label}</span></div> }

function PatientRecord({patient,onBack,onShare}) {
  return <div>
    <PageTitle eyebrow="PATIENT RECORD" title={patient.name} sub={`${patient.age} years • ${patient.sex} • ${patient.blood} • ${patient.id}`} back={onBack} action={<button className="secondary" onClick={onShare}><QrCode size={16}/> Share record</button>} />
    <div className="record-grid">
      <div className="panel">
        <div className="panel-title"><span><Activity size={18}/> Medical timeline</span><span className="pill-soft">{patient.events.length} events</span></div>
        <div className="timeline">{patient.events.map((e,i)=><TimelineItem key={i} e={e} last={i===patient.events.length-1}/>)}</div>
      </div>
      <div>
        <div className="panel compact"><div className="panel-title"><span><AlertTriangle size={18}/> Allergies</span></div><div className="allergy">{patient.allergies.join(", ")}</div></div>
        <div className="panel compact"><div className="panel-title"><span><Pill size={18}/> Current medication</span></div>{patient.medications.map((m,i)=><div className="list-row" key={i}><span>{m}</span><ChevronRight size={15}/></div>)}</div>
        <div className="panel compact"><div className="panel-title"><span><HeartPulse size={18}/> Conditions</span></div><div className="tag-wrap">{patient.conditions.map(c=><span className="tag" key={c}>{c}</span>)}</div></div>
      </div>
    </div>
  </div>
}

function TimelineItem({e,last}) {
  const Icon = e.icon==="pill" ? Pill : e.icon==="report" ? FileText : e.icon==="heart" ? HeartPulse : Stethoscope;
  return <div className="timeline-item"><div className="timeline-line">{!last && <div/>}<span><Icon size={15}/></span></div><div className="timeline-content"><span className="timeline-year">{e.year} • {e.type}</span><strong>{e.title}</strong><p>{e.place}</p></div></div>
}

function CaseTaking({patient,onBack,onComplete}) {
  const [step,setStep] = useState(0);
  const [answers,setAnswers] = useState({});
  const [input,setInput] = useState("");
  const q = questions[step];
  const progress = ((step) / questions.length) * 100;
  const submit = () => {
    if(!input.trim()) return;
    setAnswers({...answers,[q.key]:input.trim()});
    setInput("");
    if(step < questions.length-1) setStep(step+1);
    else onComplete({...answers,[q.key]:input.trim()});
  };
  return <div>
    <PageTitle eyebrow="PATIENT CASE TAKING" title="Let's understand what brought you in." sub="A conversational intake that uses your previous history to ask more relevant questions." back={onBack} />
    <div className="case-layout">
      <div className="case-main panel">
        <div className="case-progress"><span>Question {step+1} of {questions.length}</span><div><i style={{width:`${Math.max(8,progress)}%`}}/></div></div>
        <div className="context-card"><Sparkles size={17}/><div><strong>Relevant history found</strong><p>Known allergy: <b>{patient.allergies.join(", ")}</b>. The doctor will be shown this automatically.</p></div></div>
        <div className="chat">
          <div className="bubble bot"><Sparkles size={16}/>{q.bot}</div>
          {Object.entries(answers).map(([k,v])=><div className="bubble user" key={k}>{v}</div>)}
        </div>
        <div className="composer"><textarea value={input} onChange={e=>setInput(e.target.value)} placeholder={q.placeholder} onKeyDown={e=>{if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();submit()}}}/><button className="primary" onClick={submit}>{step===questions.length-1 ? "Finish" : "Next"} <ArrowRight size={16}/></button></div>
        <p className="disclaimer">Demo only — this intake does not diagnose or prescribe. A clinician must review the final case.</p>
      </div>
      <div className="panel side-summary">
        <div className="panel-title"><span><HistoryIcon/> What the doctor already knows</span></div>
        <SummaryRow label="Conditions" value={patient.conditions.join(", ")}/>
        <SummaryRow label="Medications" value={patient.medications.join(", ")}/>
        <SummaryRow label="Allergies" value={patient.allergies.join(", ")} danger/>
        <div className="divider"/>
        <div className="mini-label">WHY THIS IS DIFFERENT</div>
        <p className="muted">Case360 doesn't start from a blank form. It carries relevant history into today's case and adds today's verified information back to the timeline.</p>
      </div>
    </div>
  </div>
}

function HistoryIcon(){ return <Activity size={18}/> }
function SummaryRow({label,value,danger}) { return <div className="summary-row"><span>{label}</span><strong className={danger?"danger":""}>{value}</strong></div> }

function CaseReview({patient,onBack,onConfirm}) {
  return <div>
    <PageTitle eyebrow="AI-GENERATED CASE" title="Review today's case" sub="The clinician should verify this summary before it becomes part of the permanent record." back={onBack} action={<button className="primary" onClick={onConfirm}><Check size={17}/> Confirm case</button>} />
    <div className="review-grid">
      <div className="panel">
        <div className="ai-badge"><Sparkles size={15}/> AI PREPARED • REQUIRES CLINICIAN VERIFICATION</div>
        <h2>Clinical case summary</h2>
        <CaseBlock title="Patient"><p>{patient.name}, {patient.age}{patient.sex} • {patient.blood}</p></CaseBlock>
        <CaseBlock title="Relevant previous history"><ul><li>{patient.conditions.join(", ")}</li><li>Previous consultations and reports available in timeline</li><li className="danger">Allergy: {patient.allergies.join(", ")}</li></ul></CaseBlock>
        <CaseBlock title="Current case"><p>Patient-reported symptoms captured through conversational intake. In a production version, the AI would structure the transcript into HPI, associated symptoms, medications and other case fields.</p></CaseBlock>
      </div>
      <div className="panel"><div className="panel-title"><span><FileText size={18}/> Source records</span></div>{["Blood test — 2025","Previous prescription — 2025","Hospital discharge summary — 2024"].map(x=><div className="document-row" key={x}><FileText size={17}/><span>{x}</span><ChevronRight size={15}/></div>)}<div className="divider"/><div className="safe-note"><ShieldCheck size={17}/><span>Original records remain available for verification.</span></div></div>
    </div>
  </div>
}
function CaseBlock({title,children}){return <div className="case-block"><div className="mini-label">{title}</div>{children}</div>}

function DoctorDashboard({patients,onOpen}) {
  return <div>
    <PageTitle eyebrow="DOCTOR PORTAL" title="Good evening, Dr. Mehta" sub="Review today's patients with relevant history already prepared." action={<button className="secondary"><Plus size={16}/> Add patient</button>} />
    <div className="doctor-top"><div className="search"><Search size={17}/><input placeholder="Search patient name or ID"/></div><div className="doctor-kpis"><span><b>8</b> Today</span><span><b>3</b> Waiting</span><span><b>24</b> Records</span></div></div>
    <div className="panel"><div className="panel-title"><span><Users size={18}/> Today's patients</span><span className="pill-soft">2 active</span></div>
      {patients.map((p,i)=><div className="patient-row" key={p.id} onClick={()=>onOpen(p.id)}><div className="big-avatar small">{p.name.split(" ").map(x=>x[0]).join("")}</div><div className="patient-main"><strong>{p.name}</strong><span>{p.age}{p.sex} • {p.id} • {i===0?"Headache × 5 days":"Routine follow-up"}</span></div><div className="risk">{p.allergies[0]!=="None recorded" ? <><AlertTriangle size={15}/> Allergy</> : "No alerts"}</div><ChevronRight/></div>)}
    </div>
  </div>
}

function DoctorPatient({patient,onBack,onSave}) {
  const [rx,setRx]=useState("");
  return <div>
    <PageTitle eyebrow="DOCTOR CONSULTATION" title={patient.name} sub={`${patient.age}${patient.sex} • ${patient.id}`} back={onBack} />
    <div className="doctor-case-grid">
      <div className="panel">
        <div className="ai-badge"><Sparkles size={15}/> RELEVANT CLINICAL CONTEXT</div>
        <div className="doctor-alert"><AlertTriangle size={17}/><div><strong>Allergy: {patient.allergies.join(", ")}</strong><span>Verify before prescribing.</span></div></div>
        <CaseBlock title="Current complaint"><p>Headache for 5 days • frontal/temporal • patient-reported severity around 6/10.</p></CaseBlock>
        <CaseBlock title="Relevant previous history"><ul><li>Type 2 Diabetes</li><li>Hypertension</li><li>Previous blood test available</li><li>Previous medication history available</li></ul></CaseBlock>
        <CaseBlock title="AI notes"><p>AI has summarized the patient's available records for relevance. This is decision support only; do not rely on it as a diagnosis.</p></CaseBlock>
      </div>
      <div>
        <div className="panel"><div className="panel-title"><span><Pill size={18}/> Add prescription</span></div><textarea className="rx" value={rx} onChange={e=>setRx(e.target.value)} placeholder="e.g. Medication, dose, frequency, duration..."/><button className="primary full" disabled={!rx.trim()} onClick={()=>{onSave(rx.trim());setRx("")}}><Check size={16}/> Verify & add to timeline</button></div>
        <div className="panel"><div className="panel-title"><span><FileText size={18}/> Patient documents</span></div>{patient.events.filter(e=>e.type==="Investigation"||e.type==="Prescription").map((e,i)=><div className="document-row" key={i}><FileText size={16}/><span>{e.title}</span><ChevronRight size={15}/></div>)}</div>
      </div>
    </div>
  </div>
}

function ShareModal({onClose,onShare}) {
  const [duration,setDuration]=useState("2 hours");
  return <div className="modal-backdrop"><div className="modal"><button className="close" onClick={onClose}><X/></button><div className="modal-icon"><QrCode/></div><div className="eyebrow">PATIENT-CONTROLLED SHARING</div><h2>Share your health record</h2><p>Select what a doctor can access and how long the link remains valid.</p>
    <div className="checks">{["Medical history","Prescriptions","Lab reports","Allergies"].map((x,i)=><label key={x}><input type="checkbox" defaultChecked={i<3}/><span>{x}</span></label>)}</div>
    <div className="duration"><span>Access duration</span><div>{["30 minutes","2 hours","24 hours"].map(x=><button key={x} className={duration===x?"selected":""} onClick={()=>setDuration(x)}>{x}</button>)}</div></div>
    <div className="qr-placeholder"><QrCode size={90}/><strong>CASE360-DEMO-7F29</strong><span>Expires in {duration}</span></div>
    <button className="primary full" onClick={onShare}><Lock size={16}/> Create temporary access</button>
  </div></div>
}

export default App;
